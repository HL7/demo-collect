# Supporting Specifications - v0.1.0

## Supporting Specifications

This Implementation Guide depends on and aligns with the following specifications and initiatives.








### Cross Version Analysis

This is an R4 IG. None of the features it uses are changed in R4B, so it can be used as is with R4B systems. Packages for both [R4 (ahip.demo.r4)](../package.r4.tgz) and [R4B (ahip.demo.r4b)](../package.r4b.tgz) are available.

### FHIR

This Implementation Guide is based on **FHIR R4 (4.0.1)**. Readers should be familiar with FHIR's basic principles, resource and datatype model, and how to read FHIR specifications. Useful starting points:

* [FHIR Overview](http://hl7.org/fhir/R4/)
* [FHIR Specification Feedback](http://hl7.org/fhir/issues/) (Jira)

### HL7 and DEMo Initiative

* **HL7** – Balloting and standards development process for this IG.
* **DEMo Initiative** – Demographic Data Element Modernization (AHIP, Civitas, HL7). This IG reflects demographic content developed or endorsed through DEMo, including cognitive testing and consensus work.

### Related implementation guides (optional references)

Implementers may use this IG in conjunction with:

* **US Core** – For clinical and demographic representation in US FHIR APIs.
* **Da Vinci PDex** – For payer-to-provider and payer-to-member data exchange.
* **CARIN Blue Button** – For member-directed access to claims and related data.

Feedback on those IGs should be submitted per their respective project instructions (e.g., HL7 Jira, Da Vinci or CARIN project pages).

### Terminology and external standards

Where this IG aligns with or references external code systems (e.g., LOINC, SNOMED CT, OMB standards for race/ethnicity), implementers must comply with those specifications and their licensing terms.

### How to submit feedback on this IG

* **HL7 FHIR Jira** – For substantive change requests to this Implementation Guide: create an issue and reference this IG (e.g., "AHIP Demo IG" or the canonical URL).
* **AHIP / DEMo** – For policy or content questions related to demographic elements and DEMo alignment, refer to the [Support](support-menu.md) page or DEMo Initiative contacts.

